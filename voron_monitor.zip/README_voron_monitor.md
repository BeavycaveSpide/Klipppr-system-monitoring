# Voron Scientific Monitor

A high-fidelity system monitor for diagnosing complex Klipper printer failures (latency spikes, EMI, power issues). 

## Features

### 🔬 Scientific Accuracy
-   **Continuous USB Monitoring**: Uses a background thread to follow the kernel log (`dmesg -w`), ensuring no event is ever missed between checks.
-   **Full Power Decoding**: Decodes all 20 bits of the Pi's power register, capturing *historical* undervoltage/throttling events that happened since the last check.
-   **Drift-Compensated Timing**: Loop sleeps are calculated to maintain a precise interval, preventing measurement drift over long prints.
-   **Latency Analysis**: Runs `cyclictest` (standard RT tool) to detect sub-millisecond scheduling jitter.

### 📊 Advanced Metrics
-   **System**: CPU saturation, IO Wait %, IRQ/SoftIRQ usage, Context Switches/sec.
-   **Memory**: RAM usage, Swap usage (with low-latency threshold detection).
-   **Klipper**: Watches `klippy.log` for MCU shutdowns and timer errors.

### ⚡ Low Perturbation
-   **Buffered Logging**: Writes are buffered (flushed every 10 records) to reduce SD card IO pressure and prevent the monitor from causing the very latency it measures.
-   **Efficient Polling**: Uses non-blocking syscalls where possible.

## Installation

1.  **Install Dependencies**:
    ```bash
    sudo apt-get update
    sudo apt-get install -y python3-psutil rt-tests
    ```

2.  **Quick Install**:
    Download `voron_monitor.zip`, unzip, and run:
    ```bash
    unzip voron_monitor.zip
    cd voron_monitor_pack
    chmod +x install.sh
    ./install.sh
    ```

## Usage

Manual run (for testing):
```bash
python3 voron_monitor.py --verbose --interval 1.0
```

## CSV Output Guide

| Column | Description |
|--------|-------------|
| `max_latency_us` | Max scheduling delay in microseconds. >3000 is bad. |
| `iowait_pct` | % of time CPU is waiting for disk. High value = slow SD card. |
| `ue_hist` | "1" if undervoltage occurred *at any point* since last check. |
| `softirq_pct` | High value often indicates network packet storms (Wi-Fi). |
| `ctx_switches` | Sudden spikes indicate thread fighting/overload. |

## Troubleshooting

-   **`cyclictest not found`**: Run `sudo apt install rt-tests`.
-   **`psutil` warning**: Run `sudo apt install python3-psutil`.
