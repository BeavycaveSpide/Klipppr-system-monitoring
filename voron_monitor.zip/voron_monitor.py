#!/usr/bin/env python3
import os
import sys
import time
import csv
import subprocess
import re
import argparse
import threading
import queue
import signal
from datetime import datetime

# --- Configuration Constants ---
DEFAULT_LOG_DIR = "logs"
KLIPPER_LOG_PATH = os.path.expanduser("~/printer_data/logs/klippy.log")
VCGENCMD_PATH = "/usr/bin/vcgencmd"

# Thresholds
TEMP_WARN_THRESHOLD = 75.0      
LATENCY_WARN_US = 2000          # Stricter threshold for "clean" systems
CPU_LOAD_WARN_PERCENT = 85.0
MEM_SWAP_WARN_MB = 10           # Lowered threshold for Pi

# CSV Headers
CSV_HEADERS = [
    'timestamp', 'check_duration_ms',
    # Power
    'throttled_hex', 'ue_now', 'freq_cap_now', 'throt_now', 'soft_temp_now',
    'ue_hist', 'freq_cap_hist', 'throt_hist', 'soft_temp_hist',
    'core_voltage', 'cpu_temp', 'temp_warning',
    # System
    'cpu_usage', 'cpu_saturation', 'load_1min', 'load_5min', 'load_15min',
    'ram_used_pct', 'swap_used_mb', 'mem_pressure',
    'iowait_pct', 'irq_pct', 'softirq_pct', 'ctx_switches_delta', 'interrupts_delta',
    # Latency
    'max_latency_us', 'latency_high',
    # Events
    'usb_events', 'log_errors', 'notes'
]

# --- Monitor Component Classes ---

class MonitorBase:
    def __init__(self):
        self.name = "Base"
    def check(self):
        raise NotImplementedError
    def cleanup(self):
        pass

class USBMonitor(MonitorBase):
    def __init__(self):
        self.name = "USB"
        self.stop_event = threading.Event()
        self.log_queue = queue.Queue()
        self.thread = threading.Thread(target=self._monitor_dmesg, daemon=True)
        self.thread.start()
        
        self.patterns = [
            re.compile(r"usb disconnect", re.IGNORECASE),
            re.compile(r"reset high-speed USB device", re.IGNORECASE),
            re.compile(r"ttyACM\d+ disconnect", re.IGNORECASE),
            re.compile(r"xHCI host controller not responding", re.IGNORECASE),
            re.compile(r"under-voltage detected", re.IGNORECASE), # Kernel also sees this
            re.compile(r"voltage-status.*", re.IGNORECASE)
        ]

    def _monitor_dmesg(self):
        # Use dmesg -w to follow log. This is blocking, perfect for a thread.
        # Note: 'dmesg -w' might not work on all older busybox, but 'dmesg -w' is standard on modern PiOS.
        # Fallback: /dev/kmsg or similar if needed.
        try:
            process = subprocess.Popen(['dmesg', '-w'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            while not self.stop_event.is_set():
                line = process.stdout.readline()
                if not line:
                    break
                for pattern in self.patterns:
                    if pattern.search(line):
                        self.log_queue.put(line.strip())
            process.terminate()
        except Exception:
            pass # Thread dies silenty

    def check(self):
        events = []
        try:
            while True:
                events.append(self.log_queue.get_nowait())
        except queue.Empty:
            pass
        
        if events:
            # Deduplicate by unique strings in this batch
            unique_events = list(set(events))
            return {'usb_events': "; ".join(unique_events)}
        return None
    
    def cleanup(self):
        self.stop_event.set()

class PowerMonitor(MonitorBase):
    def __init__(self):
        self.name = "Power"

    def check(self):
        data = {}
        try:
            # Check Throttled
            res = subprocess.run([VCGENCMD_PATH, 'get_throttled'], capture_output=True, text=True)
            if res.returncode == 0:
                val_str = res.stdout.strip().split('=')[1]
                val_int = int(val_str, 16)
                data['throttled_hex'] = val_str
                
                # Current bits (0-3)
                data['ue_now'] = bool(val_int & 0x1)
                data['freq_cap_now'] = bool(val_int & 0x2)
                data['throt_now'] = bool(val_int & 0x4)
                data['soft_temp_now'] = bool(val_int & 0x8)
                
                # Historical bits (16-19) - Critical for "occasional" issues
                data['ue_hist'] = bool(val_int & 0x10000)
                data['freq_cap_hist'] = bool(val_int & 0x20000)
                data['throt_hist'] = bool(val_int & 0x40000)
                data['soft_temp_hist'] = bool(val_int & 0x80000)

            # Check Voltage
            res = subprocess.run([VCGENCMD_PATH, 'measure_volts'], capture_output=True, text=True)
            if res.returncode == 0:
                volt_str = res.stdout.strip().split('=')[1].replace('V', '')
                data['core_voltage'] = float(volt_str)

            # Check Temp
            res = subprocess.run([VCGENCMD_PATH, 'measure_temp'], capture_output=True, text=True)
            if res.returncode == 0:
                temp_str = res.stdout.strip().split('=')[1].replace("'C", '')
                temp_val = float(temp_str)
                data['cpu_temp'] = temp_val
                if temp_val > TEMP_WARN_THRESHOLD:
                    data['temp_warning'] = True
        
        except Exception:
             pass 
        return data

class SystemMonitor(MonitorBase):
    def __init__(self):
        self.name = "System"
        try:
            import psutil
            self.psutil = psutil
            # Seed cpu_percent and io counters
            self.psutil.cpu_percent(interval=None)
            self.last_io = self.psutil.cpu_times_percent(interval=None)
            self.last_ctx = self.psutil.cpu_stats()
            self.last_check_time = time.time()
        except ImportError:
            self.psutil = None
            print("Warning: psutil not installed. Essential metrics missing.")
    
    def check(self):
        data = {}
        if self.psutil:
            # Use non-blocking call with interval=None? 
            # User feedback: interval=None returns delta since last call. 
            # Since we call this periodically, it's perfect. No need to block.
            cpu_pct = self.psutil.cpu_percent(interval=None)
            data['cpu_usage'] = cpu_pct
            if cpu_pct > CPU_LOAD_WARN_PERCENT:
                data['cpu_saturation'] = True
            
            # Times percent (wait, system, user, irq)
            # This returns percentage since last call.
            times = self.psutil.cpu_times_percent(interval=None)
            data['iowait_pct'] = getattr(times, 'iowait', 0.0)
            data['irq_pct'] = getattr(times, 'irq', 0.0)
            data['softirq_pct'] = getattr(times, 'softirq', 0.0)

            # Context Switches & Interrupts
            # These are cumulative types. We need delta.
            current_ctx = self.psutil.cpu_stats()
            current_time = time.time()
            delta_t = current_time - self.last_check_time
            if delta_t > 0:
                data['ctx_switches_delta'] = int((current_ctx.ctx_switches - self.last_ctx.ctx_switches) / delta_t)
                data['interrupts_delta'] = int((current_ctx.interrupts - self.last_ctx.interrupts) / delta_t)
            
            self.last_ctx = current_ctx
            self.last_check_time = current_time
            
            # Memory
            mem = self.psutil.virtual_memory()
            swap = self.psutil.swap_memory()
            data['ram_used_pct'] = mem.percent
            data['swap_used_mb'] = round(swap.used / (1024 * 1024), 2)
            
            if data['swap_used_mb'] > MEM_SWAP_WARN_MB:
                data['mem_pressure'] = True
                
            # Load Avg
            load = os.getloadavg()
            data['load_1min'] = load[0]
            data['load_5min'] = load[1]
            data['load_15min'] = load[2]
            
        return data

class LatencyMonitor(MonitorBase):
    def __init__(self):
        self.name = "Latency"

    def check(self):
        # Scientific latency measurement using cyclictest
        # We run a short but precise text: 0.5s duration approx
        # -q: quiet, -p99: priority 99 (RT), -i200: 200us interval, -l2500: 2500 loops = 0.5s coverage
        # User requested 1s, but that blocks logging loop.
        # Compromise: blocking call of 0.5s is acceptable if interval is >1s.
        try:
            # Requires sudo for -p99 usually, or real-time group limits.
            # We used -Sp90 (Smp priority 90) before.
            cmd = ["cyclictest", "-m", "-Sp90", "-i200", "-h400", "-l2500", "-q"] 
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode == 0:
                match = re.search(r"Max:\s*(\d+)", result.stdout)
                if match:
                    max_lat = int(match.group(1))
                    return {'max_latency_us': max_lat, 
                            'latency_high': max_lat > LATENCY_WARN_US}
        except Exception:
            pass
        return None

class LogMonitor(MonitorBase):
    def __init__(self, log_path):
        self.name = "KlipperLog"
        self.log_path = log_path
        self.file_pos = 0
        self.patterns = {
            'timer_close': re.compile(r"Timer too close"),
            'mcu_shutdown': re.compile(r"MCU '.*' shutdown"),
            'lost_comm': re.compile(r"Timeout on serial communication")
        }
        if os.path.exists(self.log_path):
            self.file_pos = os.path.getsize(self.log_path)

    def check(self):
        if not os.path.exists(self.log_path): return None

        data = {}
        try:
            current_size = os.path.getsize(self.log_path)
            if current_size < self.file_pos:
                self.file_pos = 0 # Rotated
            
            if current_size > self.file_pos:
                with open(self.log_path, 'r', errors='ignore') as f:
                    f.seek(self.file_pos)
                    new_lines = f.readlines()
                    self.file_pos = f.tell()
                    
                    errors = []
                    for line in new_lines:
                        for key, pattern in self.patterns.items():
                            if pattern.search(line):
                                errors.append(f"{key}") # Just key to keep CSV clean? Or line?
                                # Brief line
                                errors.append(line.strip()[:40])

                    if errors:
                        data['log_errors'] = "; ".join(errors)

        except Exception:
            pass
        return data if data else None

# --- Logger Class ---

class CSVLogger:
    def __init__(self, directory, backup_directory=None):
        self.directory = directory
        self.backup_directory = backup_directory
        self.filename = f"voron_monitor_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        self.filepath = os.path.join(self.directory, self.filename)
        self.headers = CSV_HEADERS
        self.buffer_count = 0
        self.FLUSH_INTERVAL = 10 # Flush every 10 records to reduce SD wear/jitter
        
        if not os.path.exists(self.directory):
            os.makedirs(self.directory)
        if self.backup_directory and not os.path.exists(self.backup_directory):
            os.makedirs(self.backup_directory)

        self.file = open(self.filepath, 'w', newline='', buffering=4096)
        self.writer = csv.DictWriter(self.file, fieldnames=self.headers, extrasaction='ignore')
        self.writer.writeheader()
        self.file.flush()

        self.backup_file = None
        self.backup_writer = None
        if self.backup_directory:
            backup_path = os.path.join(self.backup_directory, self.filename)
            self.backup_file = open(backup_path, 'w', newline='', buffering=4096)
            self.backup_writer = csv.DictWriter(self.backup_file, fieldnames=self.headers, extrasaction='ignore')
            self.backup_writer.writeheader()
            self.backup_file.flush()

    def log(self, data):
        row = {'timestamp': datetime.now().isoformat()} # type: ignore
        row.update(data)
        
        try:
            self.writer.writerow(row)
            if self.backup_writer:
                self.backup_writer.writerow(row)
            
            self.buffer_count += 1
            if self.buffer_count >= self.FLUSH_INTERVAL:
                self.file.flush()
                # os.fsync(self.file.fileno()) # User requested reduced IO. Flush is enough for Python <-> OS. OS handles disk usage.
                if self.backup_file:
                    self.backup_file.flush()
                self.buffer_count = 0
                
        except Exception as e:
            print(f"Logging failed: {e}")

    def close(self):
        if self.file: self.file.close()
        if self.backup_file: self.backup_file.close()

# --- Main Execution ---

def main():
    parser = argparse.ArgumentParser(description="Voron Scientific Monitor")
    parser.add_argument("--interval", type=float, default=2.0, help="Check interval (seconds). Default 2.0 to allow for latency test.")
    parser.add_argument("--log-dir", default=DEFAULT_LOG_DIR)
    parser.add_argument("--backup-dir")
    parser.add_argument("--verbose", action='store_true')
    args = parser.parse_args()

    monitors = [
        USBMonitor(),
        PowerMonitor(),
        SystemMonitor(),
        LatencyMonitor(),
        LogMonitor(KLIPPER_LOG_PATH)
    ]

    logger = CSVLogger(args.log_dir, args.backup_dir)
    print(f"Starting Voron Scientific Monitor. PID: {os.getpid()}")
    print(f"Logging to {logger.filepath}")
    
    # Drift-compensated loop
    next_call = time.time()
    
    try:
        while True:
            # Wait for next tick
            now = time.time()
            sleep_amt = next_call - now
            if sleep_amt > 0:
                time.sleep(sleep_amt)
            
            # Start of check
            check_start = time.time()
            next_call = next_call + args.interval
            
            current_data = {}
            for m in monitors:
                try:
                    res = m.check()
                    if res:
                        current_data.update(res) # type: ignore
                except Exception as e:
                    print(f"Error {m.name}: {e}")
            
            check_dur = (time.time() - check_start) * 1000
            current_data['check_duration_ms'] = round(check_dur, 1)
            
            logger.log(current_data)
            
            if args.verbose:
                 # Print interesting only
                interesting = {k:v for k,v in current_data.items() if k not in ['timestamp', 'check_duration_ms'] and v}
                # Filter out boring 0.0 metrics
                interesting = {k:v for k,v in interesting.items() if v != 0.0 and v != False}
                if interesting:
                    print(f"Tick: {interesting}")

    except KeyboardInterrupt:
        print("\nStopping...")
        for m in monitors:
            m.cleanup()
        logger.close()

if __name__ == "__main__":
    main()


if __name__ == "__main__":
    main()
