# Voron Scientific Monitor (High-Fidelity Edition)

A minimalist, scientific diagnostic tool designed to capture the **exact root cause** of "Timer too close" errors on Raspberry Pi 3B+ systems.
It uses a persistent real-time latency probe to achieve 100% measurement coverage with <1% CPU overhead.

## Core Design Principles
1.  **Zero Blind Spots**: Uses a persistent `cyclictest` process to capture every single microsecond of latency between checks.
2.  **Targeted IRQ Correlation**: Tracks specific interrupt lines (`wlan`, `usb`, `net_rx`) to prove if Wi-Fi or USB storms are causing the latency.
3.  **Low Perturbation**: Removed all heavy libraries (`psutil`). Logs are buffered and flushed infrequently (every 60s) unless a fault is detected.

## Metrics Guide

| Column | Description | Warning Threshold |
|--------|-------------|-------------------|
| `max_lat_us` | The **worst-case** latency observed in the last 5 seconds. | > 2000 µs |
| `sirq_net_rx` | Network Receive SoftIRQs per second. Spikes here indicate packet flooding. | > 500 /sec |
| `irq_wlan` | Hard interrupts from the Wi-Fi chip. | > 200 /sec |
| `throttled_hex` | Power status bitmask (`0x50005` = Undervoltage). | Any change |
| `klipper_errors`| "Timer too close" messages from `klippy.log`. | Any |

## Installation

1.  **Install Dependencies**:
    ```bash
    sudo apt-get update
    sudo apt-get install -y rt-tests
    ```
    *(Note: `psutil` is no longer required)*

2.  **Quick Install**:
    Download `voron_monitor.zip`, unzip, and run:
    ```bash
    unzip voron_monitor.zip
    cd voron_monitor_pack
    sudo ./install.sh
    ```
    *Note: The script now runs as root (via systemd) to ensure access to `dmesg` and real-time priorities.*
