#!/bin/bash

# Configuration
INSTALL_DIR="/home/pi/voron_monitor"
SCRIPT_NAME="voron_monitor.py"
SERVICE_NAME="voron_monitor.service"

echo "--- Voron Monitor Installer (High-Fidelity) ---"

# 1. Install Dependencies
echo "[*] Installing dependencies..."
# Removed python3-psutil as it's no longer used
sudo apt-get update
sudo apt-get install -y rt-tests

# 2. setup directory
echo "[*] Setting up directory at $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
cp "$SCRIPT_NAME" "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/$SCRIPT_NAME"

# 3. Create Service
echo "[*] Creating systemd service..."
# Note: Should ideally run with real-time priority/permissions if possible
sudo bash -c "cat > /etc/systemd/system/$SERVICE_NAME" <<EOF
[Unit]
Description=Voron High-Fidelity Monitor
After=network.target

[Service]
Type=simple
User=root
# Running as root to access /proc/interrupts, dmesg, and cyclictest priority
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/$SCRIPT_NAME --log-dir $INSTALL_DIR/logs
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# 4. Enable and Start
echo "[*] Enabling and starting service..."
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME
sudo systemctl restart $SERVICE_NAME

echo "--- Installation Complete ---"
echo "Monitor is running. Logs are in $INSTALL_DIR/logs"
echo "Check status with: sudo systemctl status $SERVICE_NAME"
